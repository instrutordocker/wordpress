tinyMCE.addI18n('en.DropBoxFolderShare',{
	descripcion:"Dropbox Folder",
	titulo:"DropBox Folder Share WP",
	txt_url:"Folder URL",
	txt_ver_como_lista:"View as List",
	txt_ver_como_iconos: "View as Icons",
	txt_necesario: "Required Fields"
});