tinyMCE.addI18n('es.DropBoxFolderShare',{
	descripcion:"Carpeta Dropbox",
	titulo:"DropBox Folder Share WP",
	txt_url:"URL de carpeta",
	txt_ver_como_lista:"Ver como Lista",
	txt_ver_como_iconos: "Ver solo Iconos",
	txt_necesario: "Campos Obligatorios"
});